<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-161314-54"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-161314-54');
</script>

<div class="center_section">
<div class="text-center logo"><A HREF="https://boredhumans.com"><img class="img-responsive" id="myimg" src="https://boredhumans.b-cdn.net/images/logo.jpg" height="90" width="354"></a>
</div>     
      
