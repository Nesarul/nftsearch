<center>
<font size="4"><B>We created 50 fun artificial intelligence (AI) pages you can use for free:</B></font>
<table width="50%">
<TD>
</center>
<BR>
<?php include 'ml_links.php';?>
</td>
</table>
<BR>
<BR>
<center>
<a href="https://boredhumans.com">Back To BoredHumans.com Main Page</a></p>
</center>

<table width="80%" align="center">
            
<TD align="center">
Most machine learning programs run locally on a data scientist's PC or server, in programming languages such as Python, C++, or Java, and are not made to be accessed via a web page. We created BoredHumans.com specifically to showcase AI to the general public over the Internet.
<BR><BR>
<a target="_blank" href="https://instagram.com/boredhumansai/">
 <img src="/images/instagram.png">
</a>
<a target="_blank" href="https://twitter.com/boredhumansai/">
 <img src="/images/twitter.png">
</a>
<a target="_blank" href="https://facebook.com/BoredHumansAI/">
 <img src="/images/facebook.png">
</a>
<a target="_blank" href="https://pinterest.com/boredhumansai/">
 <img src="/images/pinterest.png">
</a>
<BR><BR>

<A HREF="privacy.php" target="new">Privacy Policy</A><BR>
(We do not save your info, sell your personal data, or do anything else to violate your privacy)
<BR><BR>
Copyright: The design of this site is Copyright 2022 by BoredHumans.com.<BR>
BoredHumans.com is owned by:<BR>
Impulse Communications, Inc.<BR>
9450 SW Gemini Dr. #56742<BR>
Beaverton, OR 97008<BR>
Email: <a href="mailto:eric@boredhumans.com">eric@boredhumans.com</a>
</TD>
</center>
