<?php
    require_once("./admin/getsllug.php");